const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
require("dotenv").config();

const app = express();
app.use(bodyParser.json());

// MongoDB connection
mongoose.connect("mongodb://127.0.0.1:27017/insightstream", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => console.log("✅ MongoDB connected"))
  .catch(err => console.log(err));

// User Schema
const UserSchema = new mongoose.Schema({
    username: String,
    email: String,
    password: String
});
const User = mongoose.model("User", UserSchema);

// Auth: Signup
app.post("/auth/signup", async (req, res) => {
    const { username, email, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ username, email, password: hashedPassword });
    await user.save();
    res.status(201).json({ message: "User registered successfully" });
});

// Auth: Login
app.post("/auth/login", async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(404).json({ message: "User not found" });

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) return res.status(401).json({ message: "Invalid password" });

    const token = jwt.sign({ userId: user._id }, "SECRET_KEY", { expiresIn: "1h" });
    res.json({ token });
});

// Sample News Route
app.get("/news", (req, res) => {
    res.json([
        { title: "Tech Trends 2025", source: "BBC", sentiment: "Positive" },
        { title: "Global Climate Update", source: "CNN", sentiment: "Neutral" }
    ]);
});
import React, { useState, useEffect } from "react";

function App() {
  const [news, setNews] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/news")
      .then(res => res.json())
      .then(data => setNews(data));
  }, []);

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>📰 Insight Stream</h1>
      <h3>Navigate the News Landscape</h3>
      <ul>
        {news.map((item, index) => (
          <li key={index}>
            <strong>{item.title}</strong> ({item.source})  
            <span> – Sentiment: {item.sentiment}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);




